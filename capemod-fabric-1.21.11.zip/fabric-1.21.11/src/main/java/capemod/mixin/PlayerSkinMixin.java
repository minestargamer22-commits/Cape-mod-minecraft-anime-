package capemod.mixin;

import capemod.CapeManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.player.SkinTextures;
import net.minecraft.util.AssetInfo;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractClientPlayerEntity.class)
public abstract class PlayerSkinMixin {
    @Inject(method = {"getSkinTextures", "getSkin"}, at = @At("RETURN"), cancellable = true)
    private void capemod$cape(CallbackInfoReturnable<SkinTextures> cir) {
        if ((Object) this != MinecraftClient.getInstance().player) return;
        SkinTextures o = cir.getReturnValue();
        cir.setReturnValue(new SkinTextures(o.body(),
            new AssetInfo.TextureAssetInfo(CapeManager.assetId()), o.elytra(), o.model(), o.secure()));
    }
}
