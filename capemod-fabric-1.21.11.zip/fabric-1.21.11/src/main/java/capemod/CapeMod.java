package capemod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class CapeMod implements ClientModInitializer {
    public static KeyBinding openMenu;
    @Override
    public void onInitializeClient() {
        CapeManager.load();
        openMenu = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.capemod.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_J,
            KeyBinding.Category.create(Identifier.of("capemod", "main"))));
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openMenu.wasPressed()) if (mc.currentScreen == null) mc.setScreen(new CapeScreen());
        });
    }
}
